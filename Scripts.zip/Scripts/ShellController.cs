﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ShellController : MonoBehaviour
{
    public Sprite ShellCrab;
    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.CompareTag("Player"))
        {
            print("Shell obtained");
            Destroy(this.gameObject);
            collision.gameObject.GetComponent<SpriteRenderer>().sprite = ShellCrab;
        }
    }
}
